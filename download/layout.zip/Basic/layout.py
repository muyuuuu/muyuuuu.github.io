import sys
import PyQt5
from mainwindow2 import Ui_MainWindow
from PyQt5.QtWidgets import QApplication, QMainWindow
from childrenform import Ui_ChildrenForm

class MyMainWindow(QMainWindow, Ui_MainWindow):

    def __init__(self, parent = None):
        super(MyMainWindow, self).__init__(parent)
        self.setupUi(self)
        self.child = ChildrenForm()
        self.actiontst.triggered.connect(self.child_show)

    def child_show(self):
        self.gridLayout.addWidget(self.child)
        self.child.show()

    def openfile(self):
        file, ok = QFileDialog.getOpenFileName(self)


class ChildrenForm(QMainWindow, Ui_ChildrenForm):
    def __init__(self):
        super(ChildrenForm, self).__init__()
        self.setupUi(self)


if __name__ == "__main__":
    app = QApplication(sys.argv)
    mywin = MyMainWindow()
    mywin.show()
    sys.exit(app.exec_())